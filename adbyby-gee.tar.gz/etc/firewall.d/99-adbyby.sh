#!/bin/sh 
# Copyright (C) 2016 evenS

/var/etc/adbyby/firewall.sh start