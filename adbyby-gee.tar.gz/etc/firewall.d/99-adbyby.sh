#!/bin/sh 
# Copyright (C) 2016 evenS

if `pidof adbyby` ; then
    /var/etc/adbyby/firewall.sh start
fi