#!/bin/sh /etc/rc.common
# Copyright (C) 2016 evenS

lan_ip=$(uci get network.lan.ipaddr)
wanip=$(lua -e "print(require'tw'.get_wan_ip())")
ADBYBY_DIR="/var/etc/adbyby"
CONFIG_DIR="/etc/adbyby"
app=adbyby
adbybyport=18309
start()
{
	echo "Starting adbyby firewall config..."
	iptables -w -t nat -N $app
	iptables -w -t nat -F $app
    iptables -w -t nat -A $app -d $lan_ip/24 -j RETURN
    iptables -w -t nat -A $app -d $wanip/24 -j RETURN
	iptables -w -t nat -A $app -m salist --salist local --match-dip -j RETURN 
	iptables -w -t nat -A $app -m salist --salist hiwifi --match-dip -j RETURN
	for mac in $(cat $CONFIG_DIR/MAC_list | awk  '{print $1}'); do
        	iptables -w -t nat -A $app -m mac --mac-source $mac -j RETURN
    done 
	iptables -w -t nat -A $app -p tcp --dport 80 -j REDIRECT --to-ports $adbybyport
	iptables -w -t nat -A  PREROUTING -i br-lan -p tcp -j $app

	iptables -w -t nat -N $app-ppp
	iptables -w -t nat -F $app-ppp
    iptables -w -t nat -A $app-ppp -d $lan_ip/24 -j RETURN
    iptables -w -t nat -A $app-ppp -d $wanip/24 -j RETURN
	iptables -w -t nat -A $app-ppp -m salist --salist local --match-dip -j RETURN 
	iptables -w -t nat -A $app-ppp -m salist --salist hiwifi --match-dip -j RETURN
	for mac in $(cat $CONFIG_DIR/MAC_list | awk  '{print $1}'); do
        	iptables -w -t nat -A $app-ppp -m mac --mac-source $mac -j RETURN
    done 
	sh $CONFIG_DIR/firwall.conf 2>/dev/null
	iptables -w -t nat -A $app-ppp -p tcp --dport 80 -j REDIRECT --to-ports $adbybyport
	iptables -w -t nat -A  PREROUTING -i ppp+ -p tcp -j $app-ppp

}
stop()
{
	echo "Stopping adbyby firewall config..."
	iptables -w -t nat -F $app 2>/dev/null
	iptables -w -t nat -D  PREROUTING -i br-lan -p tcp -j $app 2>/dev/null
	iptables -w -t nat -X $app 2>/dev/null
	
	iptables -w -t nat -F $app-ppp 2>/dev/null
	iptables -w -t nat -D  PREROUTING -i ppp+ -p tcp -j $app-ppp 2>/dev/null
	iptables -w -t nat -X $app-ppp 2>/dev/null
	
	
}

restart()
{
    stop
    sleep 3
    start
}	

