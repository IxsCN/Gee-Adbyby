#!/bin/sh /etc/rc.common
# Copyright (C) 2016 evenS

lan_ip=$(uci get network.lan.ipaddr)
source /lib/functions/network.sh
network_get_ipaddr wanip wan
ADBYBY_DIR="/var/etc/adbyby"
app=adbyby
adbybyport=18309
start()
{
	echo "Starting adbyby firewall config..."
	iptables -w -t nat -N $app
	iptables -w -t nat -F $app
    iptables -w -t nat -A $app -d $lan_ip/24 -j RETURN
    iptables -w -t nat -A $app -d $wanip/24 -j RETURN
	iptables -w -t nat -A $app -m salist --salist local --match-dip -j RETURN 
	iptables -w -t nat -A $app -m salist --salist hiwifi --match-dip -j RETURN
	for mac in $(cat $ADBYBY_DIR/MAC_list | awk  '{print $1}'); do
        	iptables -w -t nat -A $app -m mac --mac-source $mac -j RETURN
    done 
	iptables -w -t nat -A $app -p tcp --dport 80 -j REDIRECT --to-ports $adbybyport
	iptables -w -t nat -A  PREROUTING  -p tcp -j $app
}
stop()
{
	echo "Stopping adbyby firewall config..."
	if iptables -w -t nat -F $app 2>/dev/null; then
		while iptables -w -t nat -D PREROUTING -p tcp -j $app 2>/dev/null; do :; done    
		iptables -w -t nat -X $app 2>/dev/null
	fi
}

restart()
{
    stop
    sleep 3
    start
}	

