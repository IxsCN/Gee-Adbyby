#!/bin/sh /etc/rc.common
# Copyright (C) 2016 evenS

ADBYBY_DIR="/var/etc/adbyby"

user_rule(){
	rm $ADBYBY_DIR/data/user.txt
	cat $ADBYBY_DIR/data/yours.txt > $ADBYBY_DIR/data/user.txt
	[ -f $ADBYBY_DIR/data/extra.txt ] && cat $ADBYBY_DIR/data/extra.txt > $ADBYBY_DIR/data/user.txt
}

start()
{   
    $ADBYBY_DIR/adbyby&>/tmp/log/adbyby.log &
    user_rule
}

stop()
{
    ps |grep "adbyby" | grep -v 'grep' | awk '{print $1}' |xargs kill -9
    rm -f $ADBYBY_DIR/data/user.bin
}