#!/bin/sh /etc/rc.common
# Copyright (C) 2016 evenS

ADBYBY_DIR="/var/etc/adbyby"
CONFIG_DIR="/etc/adbyby"

user_rule(){
    rm -rf $ADBYBY_DIR/data/user.bin
    rm -rf $ADBYBY_DIR/data/lazy.bin
	rm -rf $ADBYBY_DIR/data/user.txt
	cat $CONFIG_DIR/yours.txt > $ADBYBY_DIR/data/user.txt
	[ -f $ADBYBY_DIR/data/extra.txt ] && cat $ADBYBY_DIR/data/extra.txt >> $ADBYBY_DIR/data/user.txt
}
user_rule
start()
{    
    $ADBYBY_DIR/adbyby&>/tmp/log/adbyby.log &
    
}

stop()
{
    ps | grep "$ADBYBY_DIR/adbyby" | grep -v 'grep' | grep -v 'adbyby.sh' | awk '{print $1}' |xargs kill -9
}