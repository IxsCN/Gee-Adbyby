#!/bin/sh
# Copyright (C) 2016 evenS

ADBYBY_PORT=18309
ADBYBY_DIR="/var/etc/adbyby"
ADBYBY_PIDS=$(pgrep -f "$ADBYBY_DIR/adbyby" | wc -l)
UPDATE_URL="https://obtxrvhhz.qnssl.com/extra.txt"
UPDATE_EXTRA_RULE="/tmp/extra.txt"
LOCAL_EXTRA_RULE=$ADBYBY_DIR/data/extra.txt

if [ "$(ps | grep /var/etc/adbyby/cron.sh | wc -l)" != 3 ]; then 
	return
fi

rm -rf $UPDATE_EXTRA_RULE
curl -ks -o $UPDATE_EXTRA_RULE $UPDATE_URL

if [ -f $UPDATE_EXTRA_RULE -a $(head -1 $UPDATE_EXTRA_RULE) != $(head -1 $LOCAL_EXTRA_RULE) ]; then
    echo "$(date +%Y-%m-%d-%H:%M:%S): adbyby user rule updating...">>/tmp/log/adbyby.log 
    cp -r $UPDATE_EXTRA_RULE $LOCAL_EXTRA_RULE
    $ADBYBY_DIR/adbyby.sh restart >/tmp/log/adbyby.log 
    return
fi

if [ "$ADBYBY_PIDS" = 0 ]; then 
	echo "$(date +%Y-%m-%d-%H:%M:%S): adbyby not running，restarting...">>/tmp/log/adbyby.log 
    $ADBYBY_DIR/adbyby.sh start >/tmp/log/adbyby.log 
fi

iptables -t nat -n --list adbyby >/dev/null 2>&1
if [ "$?" = 1 ]; then 
	echo "$(date +%Y-%m-%d-%H:%M:%S): adbyby firewall not running，restarting...">>/tmp/log/adbyby.log 
    $ADBYBY_DIR/firewall.sh start >/tmp/log/adbyby.log 
fi

