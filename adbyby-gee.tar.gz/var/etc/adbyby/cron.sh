#!/bin/sh
# Copyright (C) 2016 evenS

touch /tmp/log/adbyby.log
tail -n100 /tmp/log/adbyby.log  > /tmp/log/adbyby.log.copy ; mv -f /tmp/log/adbyby.log.copy /tmp/log/adbyby.log

trap "rm -rf '/tmp/adbyby/cron.lock' ; exit" 1 2 3 8 9 14 15
mkdir -p "/tmp/adbyby/"
if [ ! -e "/tmp/adbyby/cron.lock" ]; then

	touch "/tmp/adbyby/cron.lock"
    ADBYBY_PORT=18309
    ADBYBY_DIR="/var/etc/adbyby"
    ADBYBY_PIDS=$(pgrep -f "$ADBYBY_DIR/adbyby" | wc -l)
    UPDATE_URL="https://obtxrvhhz.qnssl.com/extra.txt"
    UPDATE_EXTRA_RULE="/tmp/extra.txt"
    LOCAL_EXTRA_RULE=$ADBYBY_DIR/data/extra.txt

    rm -rf $UPDATE_EXTRA_RULE
    curl -ks -o $UPDATE_EXTRA_RULE $UPDATE_URL

    if [ -f $UPDATE_EXTRA_RULE -a $(head -1 $UPDATE_EXTRA_RULE) != $(head -1 $LOCAL_EXTRA_RULE) ]; then
        echo "$(date +%Y-%m-%d-%H:%M:%S): adbyby user rule updating...">>/tmp/log/adbyby.log 
        cp -r $UPDATE_EXTRA_RULE $LOCAL_EXTRA_RULE
        $ADBYBY_DIR/adbyby.sh restart
        return
    fi

    if [ "$ADBYBY_PIDS" = 0 ]; then 
        echo "$(date +%Y-%m-%d-%H:%M:%S): adbyby not running，restarting...">>/tmp/log/adbyby.log 
        $ADBYBY_DIR/adbyby.sh start
    fi

    iptables -t nat -n --list adbyby >/dev/null 2>&1
    if [ "$?" = 1 ]; then 
        echo "$(date +%Y-%m-%d-%H:%M:%S): adbyby firewall not running，restarting...">>/tmp/log/adbyby.log 
        $ADBYBY_DIR/firewall.sh start
    fi
    rm -rf '/tmp/adbyby/cron.lock'

else
	exit
fi
