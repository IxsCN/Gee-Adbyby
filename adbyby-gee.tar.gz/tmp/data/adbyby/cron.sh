#!/bin/sh
# Copyright (C) 2016 evenS

ADBYBY_PORT=18309
ADBYBY_DIR="/tmp/data/adbyby"
ADBYBY_PIDS=$(pgrep -f "$ADBYBY_DIR/adbyby" | wc -l)
FIREWALL=$(iptables -w -t nat -L | grep $ADBYBY_PORT | wc -l)
UPDATE_URL="http://7xt1v0.com1.z0.glb.clouddn.com/extra.txt"
UPDATE_EXTRA_RULE="/tmp/extra.txt"
LOCAL_EXTRA_RULE=$ADBYBY_DIR"/data/extra.txt"

rm $UPDATE_EXTRA_RULE
curl -o $UPDATE_EXTRA_RULE $UPDATE_URL

if [ -f $UPDATE_EXTRA_RULE -a $(head -1 $LOCAL_EXTRA_RULE) != $(head -1 $LOCAL_EXTRA_RULE) ]; then
    echo "$(date +%H:%M:%S): adbyby user rule updating...">>/tmp/log/safe.log 
    cp -r $UPDATE_EXTRA_RULE $LOCAL_EXTRA_RULE
    /etc/init.d/adbyby restart
    return
fi

if [ "$ADBYBY_PIDS" = 0 ]; then 
	echo "$(date +%H:%M:%S): adbyby not running，restarting...">>/tmp/log/safe.log 
    $ADBYBY_DIR/adbyby restart & >/tmp/log/adbyby.log &
fi

if [ "$FIREWALL" = 0 ]; then 
	echo "$(date +%H:%M:%S): adbyby firewall not running，restarting...">>/tmp/log/safe.log 
    $ADBYBY_DIR/adfirewall.sh start
fi


